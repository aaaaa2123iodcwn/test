//
//  ItemCell.swift
//  LootLogger
//
//  Created by Marco Raro Moreno on 10/7/24.
//


import UIKit

class ItemCell: UITableViewCell {

    @IBOutlet var nameLabel:UILabel!
    @IBOutlet var serialNumberLabel:UILabel!
    @IBOutlet var valueLabel:UILabel!
}
