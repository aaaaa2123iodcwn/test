//
//  ViewController.swift
//  LootLogger
//
//  Created by Marco Raro Moreno on 10/8/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

